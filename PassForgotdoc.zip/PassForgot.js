import React from "react";

function PassForgot() {
    return(
        <div>







<div className="caseRem">
    <label htmlFor="email"><span className="color_bleu">E</span>mail: <span className="color_bleu">* </span></label>
<input type="email" name="email" />
</div>



            <div className="submit">

                <button type="submit" className="btn btn-outline-success"> Envoyer </button>
            </div>

        </div>
    );
}
export default PassForgot;